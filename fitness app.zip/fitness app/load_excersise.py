import sys
from app import create_app
from models import Exercise, db

# Initialize Flask app
app = create_app()

# Sample data for exercises (you can replace this with your actual data)
exercises_data = [
    {'name': 'Push Up', 'description': 'Chest, Shoulders and Triceps.'},
    {'name': 'Bench Press', 'description': 'Chest, Shoulders and Triceps.'},
    {'name': 'Dips', 'description': 'Chest and Triceps.'},
    {'name': 'Shoulder Press', 'description': 'Shoulders and Triceps.'},
    {'name': 'Lateral raise', 'description': 'Shoulders'},
    {'name': 'Tricep extension', 'description': 'Triceps.'},
    {'name': 'Squat', 'description': 'Quads, Hamstrings and Glutes'},
    {'name': 'Leg Press', 'description': 'Quads and Hamstrings'},
    {'name': 'Hamstring Curl', 'description': 'Hamstrings'},
    {'name': 'Leg extension', 'description': 'Quads'},
    {'name': 'Deadlift', 'description': 'Back, Glutes, Hamstrings'},
    {'name': 'Plank', 'description': 'Core/Abs'},
    {'name': 'Sit-ups', 'description': 'Core/Abs'},
    {'name': 'Treadmill', 'description': 'Cardio'},
    {'name': 'Stair master', 'description': 'Cardio'},
    {'name': 'Barbell row', 'description': 'Back and Biceps'},
    {'name': 'Lat Pulldown', 'description': 'Back and Biceps'},
    {'name': 'Pull Up', 'description': 'Back and Biceps'},
    {'name': 'Bicep Curl', 'description': 'Biceps'}
]

# Function to replace exercises in the database
def replace_exercises():
    with app.app_context():  # Ensure we're within the app context
        # Delete all existing exercises
        db.session.query(Exercise).delete()
        db.session.commit()

        # Add new exercises
        for exercise in exercises_data:
            new_exercise = Exercise(
                name=exercise['name'],
                description=exercise['description']
            )
            db.session.add(new_exercise)
        
        # Commit all new exercises to the database
        db.session.commit()
        print(f"Replaced all exercises with {len(exercises_data)} new entries.")

# Run the script
if __name__ == '__main__':
    replace_exercises()
