from app import app, db
from sqlalchemy import inspect

with app.app_context():
    inspector = inspect(db.engine)
    tables = inspector.get_table_names()
    print("Tables in the database:", tables)

    # Check columns of the workout_plans table
    if 'workout_plans' in tables:
        columns = inspector.get_columns('workout_plans')
        print("Columns in 'workout_plans':")
        for column in columns:
            print(column)
    else:
        print("Table 'workout_plans' does not exist.")
