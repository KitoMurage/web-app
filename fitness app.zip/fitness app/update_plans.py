from app import create_app, db
from models import WorkoutPlan

app = create_app()

def update_workout_plan_group_labels():
    with app.app_context():
        # List of group labels for existing plans
        group_label_updates = {
            'Full Body': 'Full body Series',
            'Push': 'PPL',
            'Pull': 'PPL',
            'Legs': 'PPL',
            'Cardio & Core': 'Cardio'
        }

        for plan_name, new_group_label in group_label_updates.items():
            # Query for the workout plan by name
            plan = WorkoutPlan.query.filter_by(name=plan_name, is_default=True).first()
            if plan:
                # Update the group label if needed
                if plan.group_label != new_group_label:
                    plan.group_label = new_group_label
                    db.session.commit()
                    print(f"Updated '{plan_name}' plan with new group label: {new_group_label}")
                else:
                    print(f"'{plan_name}' already has the correct group label.")
            else:
                print(f"Workout plan '{plan_name}' not found.")

if __name__ == "__main__":
    update_workout_plan_group_labels()
