from app import create_app, db
from models import WorkoutPlan, Exercise, WorkoutPlanExercises, User

app = create_app()
# Predefined workout plans
default_workout_plans = [
    {
        'name': 'Full Body',
        'description': 'A full-body workout for building strength.',
        'group_label': 'Full body Series',
        'exercises': [
            {'name': 'Bench Press', 'sets': 4, 'reps': 6},
            {'name': 'Shoulder Press', 'sets': 3, 'reps': 8},
            {'name': 'Pull Up', 'sets': 3, 'reps': 8},
            {'name': 'Squat', 'sets': 4, 'reps': 8},
            {'name': 'Deadlift', 'sets': 4, 'reps': 6},
        ]
    },
        {
        'name': 'Home workout',
        'description': 'No equipment? No problem!',
        'group_label': 'Full body Series',
        'exercises': [
            {'name': 'Push Up', 'sets': 4, 'reps': 10},
            {'name': 'Squat', 'sets': 3, 'reps': 20},
            {'name': 'Pull Up', 'sets': 3, 'reps': 8},
            {'name': 'Plank', 'sets': 1, 'reps': 30},
            {'name': 'Sit-ups', 'sets': 2, 'reps': 20},
        ]
    },
     {
        'name': 'Push',
        'description': 'A muscle building workout that focuses on building the Chest, Shoulders and Triceps. This workout is paired well with the other plans labled PPL',
        'group_label': 'PPL',
        'exercises': [
            {'name': 'Push Up', 'sets': 1, 'reps': 20},
            {'name': 'Bench Press', 'sets': 4, 'reps': 8},
            {'name': 'Shoulder Press', 'sets': 3, 'reps': 8},
            {'name': 'Dips', 'sets': 3, 'reps': 8},
            {'name': 'Lateral raise', 'sets': 4, 'reps': 15},
            {'name': 'Tricep extension', 'sets': 3, 'reps': 8},
        ]
    },
    {
        'name': 'Pull',
        'description': 'A muscle building workout that focuses on building the Back and Biceps. This workout is paired well with the other plans labled PPL',
        'group_label': 'PPL',
        'exercises': [
            {'name': 'Deadlift', 'sets': 3, 'reps': 6},
            {'name': 'Lat Pulldown', 'sets': 4, 'reps': 10},
            {'name': 'Barbell row', 'sets': 4, 'reps': 10},
            {'name': 'Bicep Curl', 'sets': 4, 'reps': 12},
        ]
    },

    {
        'name': 'Legs',
        'description': 'A muscle building workout that focuses on building the Quads, Hamstrings and Glutes. This workout is paired well with the other plans labled PPL',
        'group_label': 'PPL',
        'exercises': [
            {'name': 'Squat', 'sets': 3, 'reps': 10},
            {'name': 'Leg Press', 'sets': 3, 'reps': 10},
            {'name': 'Leg extension', 'sets': 4, 'reps': 10},
            {'name': 'Hamstring Curl', 'sets': 4, 'reps': 10},
        ]
    },
    {
        'name': 'Cardio & Core',
        'description': 'Improve endurance and core strength.',
        'group_label': 'Leg Day Series',
        'exercises': [
            {'name': 'Plank', 'sets': 3, 'reps': 30},
            {'name': 'Treadmill', 'sets': 1, 'reps': 20},  
            {'name': 'Sit-ups', 'sets': 3, 'reps': 15},
        ]
    },
]

def populate_default_workout_plans():
    with app.app_context():
        # Ensure an admin user exists
        admin_user = User.query.filter_by(username='admin').first()
        if not admin_user:
            admin_user = User(username='admin', password='adminpassword')  # Use secure hashing in production
            db.session.add(admin_user)
            db.session.commit()
            print("Admin user created.")

        for plan_data in default_workout_plans:
            existing_plan = WorkoutPlan.query.filter_by(name=plan_data['name'], is_default=True).first()
            if existing_plan:
                print(f"Workout plan '{plan_data['name']}' already exists.")
                continue

            # Create a new workout plan, including the group_label
            new_plan = WorkoutPlan(
                name=plan_data['name'],
                description=plan_data['description'],
                group_label=plan_data['group_label'],  # Include the group label here
                user_id=admin_user.id,
                is_default=True
            )

            for exercise_data in plan_data['exercises']:
                exercise = Exercise.query.filter_by(name=exercise_data['name']).first()
                if not exercise:
                    exercise = Exercise(name=exercise_data['name'])
                    db.session.add(exercise)
                    db.session.commit()  # Ensure the ID is available

                plan_exercise = WorkoutPlanExercises(
                    workout_plan=new_plan,
                    exercise=exercise,
                    sets=exercise_data['sets'],
                    reps=exercise_data['reps']
                )
                new_plan.workout_plan_exercises.append(plan_exercise)

            db.session.add(new_plan)
        db.session.commit()
        print("Default workout plans populated successfully.")

if __name__ == "__main__":
    populate_default_workout_plans()