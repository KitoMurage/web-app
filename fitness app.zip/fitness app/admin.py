from app import create_app, db
from models import User
from werkzeug.security import generate_password_hash

app = create_app()

def create_admin_user():
    with app.app_context():
        # Check if an admin user already exists
        admin_user = User.query.filter_by(username='admin').first()
        if admin_user:
            print("Admin user already exists.")
            return

        # Create a new admin user
        new_admin = User(
            username='admin',
            password=generate_password_hash('adminpassword123', method='sha256')  # Replace with a secure password
        )

        db.session.add(new_admin)
        db.session.commit()
        print("Admin user created successfully.")

if __name__ == "__main__":
    create_admin_user()
