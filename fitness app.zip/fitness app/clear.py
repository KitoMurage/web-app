from app import create_app, db
from models import User

app = create_app()

with app.app_context():
    db.session.query(User).delete()  # Deletes all User records
    db.session.commit()
    print("All users have been cleared from the database.")
